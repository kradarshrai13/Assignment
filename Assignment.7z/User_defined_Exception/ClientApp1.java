package User_defined_Exception;

public class ClientApp1
{
	static void disp()throws MyException
	{
		Calc c=new Calc();
		int result=0;
		result=c.multi(-2);
		System.out.println(result);
	}
	public static void main(String args[])
	{
		try
		{
			disp();
		}
		catch(MyException m)
		{
			
			System.out.println("error detected");
		}
		finally {
			
		System.out.println("this is finally block");
		}
	}
}
		