package User_defined_Exception;

@SuppressWarnings("serial")
public class MyException extends Exception
{
	public MyException(String e)
	{
		super(e);
		
	}
}
